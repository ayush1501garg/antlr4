# ANTLR4
The binaries of the ANTLR4 parser generator with some scripts

See [ANTLR Website](https://www.antlr.org/) for the original distribution of ANTLR.